<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm fixed-bottom mt-5">
    <a class="navbar-brand mx-auto" href="{{ url('/') }}">
    {{ config('app.name', 'Laravel') }}
    </a>
</nav>
