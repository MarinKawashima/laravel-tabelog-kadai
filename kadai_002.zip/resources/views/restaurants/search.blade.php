@extends('layouts.app')

@section('content')
    <h1> "{{ $keyword }}" の検索結果</h1>

    @if($restaurants->count() > 0)
        <ul>
            @foreach($restaurants as $restaurant)
                <!-- 店舗の画像も挿入する img -->
                <li>{{ $restaurant->name }}</li>
            @endforeach
        </ul>
    @else
        <p>お店は見つかりませんでした。</p>
    @endif
@endsection
