<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RestaurantController;
use App\Http\Controllers\category_restaurantController;
use App\Http\Controllers\WebController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\FavoriteController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/',  [WebController::class, 'index'])->name('top');


require __DIR__.'/auth.php';


// カテゴリとレストランの関連付けを追加するルート
Route::post('/categories/{category_id}/restaurants/{restaurant_id}', [category_restaurantController::class, 'store'])
    ->name('categories.restaurants.attach');

// カテゴリとレストランの関連付けを削除するルート
Route::delete('/categories/{category_id}/restaurants/{restaurant_id}', [category_restaurantController::class, 'destroy'])
    ->name('categories.restaurants.detach');

Route::get('/restaurants/search', [RestaurantController::class, 'search'])->name('restaurants.search');
Route::get('/restaurants/category/{categoryId}', [RestaurantController::class, 'category'])->name('restaurants.category');
Route::get('/restaurants/{id}', [RestaurantController::class, 'show'])->name('restaurants.show');



// ログイン・メール認証済みユーザーに関するルート
Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('restaurants', RestaurantController::class);
    // レビュー用のルート
    Route::post('reviews', [ReviewController::class, 'store'])->name('reviews.store');

    Route::post('favorites/{restaurant_id}', [FavoriteController::class, 'store'])->name('favorites.store');
    Route::delete('favorites/{restaurant_id}', [FavoriteController::class, 'destroy'])->name('favorites.destroy');

    Route::controller(UserController::class)->group(function () {
        Route::get('users/mypage', 'mypage')->name('mypage');
        Route::get('users/mypage/edit', 'edit')->name('mypage.edit');
        Route::put('users/mypage', 'update')->name('mypage.update');
        Route::delete('users/mypage/delete', 'destroy')->name('mypage.destroy');
    });
});

